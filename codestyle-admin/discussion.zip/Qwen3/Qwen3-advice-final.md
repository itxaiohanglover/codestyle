# Qwen3 最终优化建议文档

## 1. 引言

本文档是在分析了其他智能体（seek、GLM、MiniMax）的优化建议后，结合当前项目的实际情况，提出的综合性优化方案。目标是提升 codestyle-plugin-search 模块的性能、可扩展性和用户体验。

## 2. 当前系统分析

### 2.1 现有功能局限性

通过分析 `RemoteSearchESRepository.java` 文件发现：
1. **单结果返回限制**：每次搜索只返回一个结果，无法满足多样化的用户需求。
2. **基础搜索算法**：仅使用简单的 `match` 查询，缺乏高级搜索功能如模糊匹配、权重调整等。
3. **性能瓶颈**：缺少缓存机制，每次请求都直接访问 Elasticsearch，增加了响应时间。
4. **未充分利用 ES 特性**：Mapping 中定义了 `semantic_text` 和 `pinyin_analyzer` 字段，但未被实际使用。

### 2.2 数据同步问题

通过分析 Canal 相关配置和策略类发现：
1. **全量同步效率低**：采用逐条插入的方式，对于大量数据同步场景效率低下。
2. **增量同步可靠性不足**：缺乏完善的重试机制和死信队列处理。

### 2.3 缓存缺失

目前没有实现任何缓存机制，导致数据库压力大，响应速度慢。

## 3. 优化方案总览

| 优化方向 | 具体措施 |
|---------|----------|
| 搜索功能增强 | 多字段搜索、权重查询、模糊匹配、分页支持、智能排序 |
| 混合搜索架构 | 关键词搜索 + 向量搜索 + 语义搜索 |
| 性能优化 | 多级缓存（Caffeine + Redis）、异步处理 |
| 数据同步优化 | 批量处理、重试机制、死信队列 |
| 可观测性提升 | 添加监控指标、分布式追踪 |
| 安全加固 | 输入验证、SQL 注入防护、限流 |

## 4. 核心优化点详解

### 4.1 搜索功能增强

#### 4.1.1 多字段搜索与权重调整
```java
// 修改 RemoteSearchESRepository.java 中的 searchInES 方法
public List<RemoteMetaConfigVO> searchInES(String keyword) {
    try {
        // 创建 BoolQueryBuilder 来组合多个查询条件
        BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
        
        // 在 description 字段上进行全文匹配查询，并设置较高权重
        boolQuery.should(QueryBuilders.matchQuery("description", keyword).boost(2.0f));
        
        // 在 name 字段上进行匹配查询
        boolQuery.should(QueryBuilders.matchQuery("name", keyword));
        
        // 在 tags 字段上进行匹配查询
        boolQuery.should(QueryBuilders.matchQuery("tags", keyword));
        
        // 构建查询对象并设置分页参数
        NativeSearchQueryBuilder searchQuery = new NativeSearchQueryBuilder()
                .withQuery(boolQuery)
                .withPageable(PageRequest.of(0, 10)); // 默认返回前10个结果
        
        SearchHits<RemoteMetaDoc> searchHits = elasticsearchOperations.search(searchQuery.build(), RemoteMetaDoc.class);
        
        return searchHits.getSearchHits().stream()
                .map(hit -> converToResultVO(hit.getContent()))
                .collect(Collectors.toList());
                
    } catch (Exception e) {
        log.error("检索异常: {}", e.getMessage(), e);
        return Collections.emptyList();
    }
}
```

#### 4.1.2 模糊匹配支持
```java
// 添加模糊匹配选项
boolQuery.should(QueryBuilders.fuzzyQuery("description", keyword).fuzziness(Fuzziness.AUTO));
```

#### 4.1.3 分页与排序
```java
// 支持分页和自定义排序
NativeSearchQueryBuilder searchQuery = new NativeSearchQueryBuilder()
        .withQuery(boolQuery)
        .withPageable(PageRequest.of(pageNum, pageSize))
        .withSort(SortBuilders.scoreSort().order(SortOrder.DESC)); // 按相关度得分排序
```

### 4.2 混合搜索架构

#### 4.2.1 激活 semantic_text 功能
根据 `_mapping.json` 中已有的配置，需要在 Elasticsearch 中启用 InferenceService 并正确配置 semantic_text 查询：

```java
@Configuration
public class SemanticSearchConfig {
    
    @Bean
    public InferenceService inferenceService() {
        // 配置完整的推理服务，激活semantic_text真正能力
        return InferenceService.builder()
            .modelId(".multilingual-e5-small-elasticsearch")
            .taskType("text_embedding")
            .service("elser")
            .build();
    }
    
    @Bean  
    public SemanticTextQueryBuilder semanticTextQueryBuilder() {
        // 构建完整的语义查询，包括推理配置
        return SemanticTextQueryBuilder.builder()
            .inferenceConfig(inferenceService())
            .similarityThreshold(0.7f)
            .maxResults(50)
            .build();
    }
}
```

#### 4.2.2 实现混合搜索
```java
@Service
public class HybridSearchService {
    
    @Autowired
    private ElasticsearchRestTemplate elasticsearchTemplate;
    
    public List<RemoteMetaConfigVO> hybridSearch(String keyword) {
        // 关键词搜索
        List<RemoteMetaConfigVO> keywordResults = keywordSearch(keyword);
        
        // 语义搜索
        List<RemoteMetaConfigVO> semanticResults = semanticSearch(keyword);
        
        // 合并去重并按相关性排序
        Map<String, RemoteMetaConfigVO> mergedResults = new LinkedHashMap<>();
        
        // 优先保留关键词搜索的结果
        keywordResults.forEach(result -> mergedResults.put(result.getId(), result));
        
        // 添加语义搜索结果
        semanticResults.forEach(result -> {
            if (!mergedResults.containsKey(result.getId())) {
                mergedResults.put(result.getId(), result);
            }
        });
        
        return new ArrayList<>(mergedResults.values());
    }
    
    private List<RemoteMetaConfigVO> keywordSearch(String keyword) {
        // 实现关键词搜索逻辑
        // ...
    }
    
    private List<RemoteMetaConfigVO> semanticSearch(String keyword) {
        // 实现语义搜索逻辑
        // 使用 semantic_text 字段进行查询
        SemanticTextQueryBuilder builder = semanticTextQueryBuilder();
        builder.queryText(keyword);
        
        // 执行查询
        // ...
    }
}
```

### 4.3 多级缓存架构

#### 4.3.1 缓存架构设计
采用三级缓存架构：
1. **L1 Cache (本地缓存)**: 使用 Caffeine，提供最快的访问速度。
2. **L2 Cache (分布式缓存)**: 使用 Redis，解决多实例共享问题。
3. **L3 Cache (数据库/Elasticsearch)**: 最底层的数据源。

#### 4.3.2 缓存实现
```java
@Service
public class CachedSearchService {
    
    private final LoadingCache<String, List<RemoteMetaConfigVO>> localCache;
    private final RedisTemplate<String, Object> redisTemplate;
    
    public CachedSearchService(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
        this.localCache = Caffeine.newBuilder()
            .maximumSize(10_000)
            .expireAfterWrite(10, TimeUnit.MINUTES)
            .build(key -> loadFromRedisOrDB(key));
    }
    
    public List<RemoteMetaConfigVO> searchWithCache(String keyword) {
        // L1: 尝试从本地缓存获取
        List<RemoteMetaConfigVO> cached = localCache.getIfPresent(keyword);
        if (cached != null) {
            return cached;
        }
        
        // L2: 尝试从Redis获取
        String redisKey = "search:result:" + keyword;
        List<RemoteMetaConfigVO> redisResult = (List<RemoteMetaConfigVO>) redisTemplate.opsForValue().get(redisKey);
        if (redisResult != null) {
            localCache.put(keyword, redisResult); // 回填L1
            return redisResult;
        }
        
        // L3: 调用底层搜索接口，并将结果写入缓存
        List<RemoteMetaConfigVO> dbResult = performActualSearch(keyword);
        redisTemplate.opsForValue().set(redisKey, dbResult, Duration.ofMinutes(30)); // 写入Redis
        localCache.put(keyword, dbResult); // 回填L1
        
        return dbResult;
    }
    
    private List<RemoteMetaConfigVO> loadFromRedisOrDB(String keyword) {
        String redisKey = "search:result:" + keyword;
        List<RemoteMetaConfigVO> redisResult = (List<RemoteMetaConfigVO>) redisTemplate.opsForValue().get(redisKey);
        if (redisResult != null) {
            return redisResult;
        }
        
        List<RemoteMetaConfigVO> dbResult = performActualSearch(keyword);
        redisTemplate.opsForValue().set(redisKey, dbResult, Duration.ofMinutes(30));
        return dbResult;
    }
    
    private List<RemoteMetaConfigVO> performActualSearch(String keyword) {
        // 实际调用搜索引擎或数据库获取数据
        // 这里可以调用前面实现的混合搜索方法
        return hybridSearchService.hybridSearch(keyword);
    }
}
```

### 4.4 数据同步优化

#### 4.4.1 批量处理优化
修改 `FullSyncStrategy.java` 以支持批量插入：

```java
@Component
public class FullSyncStrategy implements SyncStrategy {
    
    private static final int BATCH_SIZE = 1000; // 批量大小
    
    @Override
    public void syncAll() {
        List<RemoteMetaConfigVO> dataList = fetchDataFromSource(); // 获取所有数据
        
        // 分批处理
        for (int i = 0; i < dataList.size(); i += BATCH_SIZE) {
            int endIndex = Math.min(i + BATCH_SIZE, dataList.size());
            List<RemoteMetaConfigVO> batch = dataList.subList(i, endIndex);
            
            // 批量保存到 Elasticsearch
            List<IndexQuery> queries = batch.stream()
                .map(this::buildIndexQuery)
                .collect(Collectors.toList());
                
            elasticsearchRestTemplate.bulkIndex(queries, RemoteMetaDoc.class);
            
            log.info("已完成批量同步，批次大小: {}", batch.size());
        }
    }
    
    private IndexQuery buildIndexQuery(RemoteMetaConfigVO vo) {
        return new IndexQueryBuilder()
            .withId(vo.getId())
            .withObject(converToDoc(vo))
            .build();
    }
}
```

#### 4.4.2 增强重试机制
修改 `IncrementalSyncStrategy.java` 添加更完善的重试和死信队列处理：

```java
@Component
public class IncrementalSyncStrategy implements SyncStrategy {
    
    private static final int MAX_RETRY_COUNT = 3;
    private static final String DEAD_LETTER_QUEUE = "sync_dead_letter_queue";
    
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    
    @Override
    public void syncIncremental(CanalEntry.Entry entry) {
        try {
            processEntry(entry);
        } catch (Exception e) {
            handleSyncFailure(entry, e);
        }
    }
    
    private void processEntry(CanalEntry.Entry entry) throws Exception {
        // 原始处理逻辑
        // ...
    }
    
    private void handleSyncFailure(CanalEntry.Entry entry, Exception e) {
        String entryKey = "failed_entry:" + UUID.randomUUID().toString();
        Integer retryCount = (Integer) redisTemplate.opsForValue().get(entryKey + ":retry_count");
        
        if (retryCount == null) {
            retryCount = 0;
        }
        
        if (retryCount < MAX_RETRY_COUNT) {
            // 重新放入队列等待重试
            redisTemplate.opsForValue().set(entryKey + ":retry_count", retryCount + 1);
            redisTemplate.opsForList().leftPush("sync_retry_queue", entry);
            log.warn("同步失败，已尝试 {} 次，稍后重试", retryCount + 1, e);
        } else {
            // 移入死信队列
            redisTemplate.opsForList().leftPush(DEAD_LETTER_QUEUE, entry);
            log.error("同步失败超过最大重试次数，已移入死信队列", e);
        }
    }
}
```

### 4.5 可观测性提升

#### 4.5.1 添加监控指标
```java
@Component
public class SearchMetrics {
    
    private final MeterRegistry meterRegistry;
    private final Timer searchTimer;
    private final Counter cacheHitCounter;
    private final Counter cacheMissCounter;
    
    public SearchMetrics(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        this.searchTimer = Timer.builder("search.duration")
                .description("搜索请求耗时")
                .register(meterRegistry);
        this.cacheHitCounter = Counter.builder("cache.hit")
                .description("缓存命中次数")
                .tag("layer", "l1")
                .register(meterRegistry);
        this.cacheMissCounter = Counter.builder("cache.miss")
                .description("缓存未命中次数")
                .tag("layer", "l1")
                .register(meterRegistry);
    }
    
    public <T> T recordSearchTime(Supplier<T> searchOperation) {
        return searchTimer.record(searchOperation);
    }
    
    public void recordCacheHit() {
        cacheHitCounter.increment();
    }
    
    public void recordCacheMiss() {
        cacheMissCounter.increment();
    }
}
```

#### 4.5.2 集成分布式追踪
确保项目中已引入 Spring Cloud Sleuth 或类似的追踪组件，并在关键业务方法上添加 `@NewSpan` 注解：

```java
@Service
public class CachedSearchService {
    
    @Autowired
    private SearchMetrics searchMetrics;
    
    @NewSpan("cached-search")
    public List<RemoteMetaConfigVO> searchWithCache(String keyword) {
        return searchMetrics.recordSearchTime(() -> {
            // 原始搜索逻辑
            // ...
        });
    }
}
```

### 4.6 安全加固

#### 4.6.1 输入验证与清理
```java
@Service
public class SearchService {
    
    public List<RemoteMetaConfigVO> search(String keyword) {
        // 输入验证
        if (StringUtils.isBlank(keyword)) {
            throw new IllegalArgumentException("搜索关键词不能为空");
        }
        
        // 长度限制
        if (keyword.length() > 100) {
            throw new IllegalArgumentException("搜索关键词长度不能超过100个字符");
        }
        
        // SQL 注入防护（如果涉及数据库查询）
        String sanitizedKeyword = sanitizeInput(keyword);
        
        // XSS 防护
        String escapedKeyword = HtmlUtils.htmlEscape(sanitizedKeyword);
        
        return cachedSearchService.searchWithCache(escapedKeyword);
    }
    
    private String sanitizeInput(String input) {
        // 移除潜在的恶意字符
        return input.replaceAll("[<>\"'%;)(&+]", "");
    }
}
```

#### 4.6.2 接口限流
使用 Resilience4j 或 Sentinel 实现限流：

```java
@RestController
@RequestMapping("/api/search")
public class SearchController {
    
    @Autowired
    private SearchService searchService;
    
    @RateLimiter(name = "searchApi")
    @GetMapping
    public ResponseEntity<List<RemoteMetaConfigVO>> search(@RequestParam String keyword) {
        List<RemoteMetaConfigVO> results = searchService.search(keyword);
        return ResponseEntity.ok(results);
    }
}
```

## 5. 依赖升级建议

### 5.1 Elasticsearch 升级
考虑将 Elasticsearch 升级至 9.x 版本，以获得更好的性能和新特性支持，特别是 semantic_text 功能。

### 5.2 引入 Disruptor
为了提高数据同步的吞吐量和降低延迟，建议引入 Disruptor 作为异步事件处理框架：

```xml
<dependency>
    <groupId>com.lmax</groupId>
    <artifactId>disruptor</artifactId>
    <version>3.4.4</version>
</dependency>
```

### 5.3 Redis 配置确认
已在 `codestyle-common/pom.xml` 中确认包含 Redis 依赖 (`continew-starter-cache-jetcache`)，可用于实现分布式缓存。

## 6. 总结

本优化方案综合了多个方面的改进措施，旨在全面提升 codestyle-plugin-search 模块的功能完整性、性能表现和系统稳定性。通过实施这些优化，预期能够显著改善用户体验，同时为系统的长期发展奠定坚实基础。